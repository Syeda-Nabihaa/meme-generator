import { defineConfig, transformWithEsbuild } from "vite";
import react from "@vitejs/plugin-react";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react(),
    {
      name: "load+transform-js-files-as-jsx",
      async transform(code, id) {
        if (id.endsWith(".js")) {
          return transformWithEsbuild(code, id, {
            loader: "jsx", // Use JSX loader
            jsx: "automatic", // Enable automatic JSX transform
          });
        }
        return null;
      },
    },
  ],
  optimizeDeps: {
    esbuildOptions: {
      loader: {
        ".js": "jsx", // Treat .js files as JSX
      },
    },
  },
  server: {
    host: "0.0.0.0",
  },
});
