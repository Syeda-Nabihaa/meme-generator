import axios from "axios";
import { allEndPoints } from "../apiUrl";

export default class Authentication {
  async userLogin(body) {
    try {
      console.log(allEndPoints.loginUser);
      
      const response = await axios.post(allEndPoints.loginUser, body, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      return response;
    } catch (error) {
      console.error("Error:", error.response || error.message);
      throw error; // Optional: re-throw the error for upstream handling
    }
  }

  async adminLogin(body) {
    try {
      const response = await axios.post(allEndPoints.loginAdmin, body, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      return response.data;
    } catch (error) {
      console.error("Error:", error.response?.data || error.message);
      throw error;
    }
  }

  async signUpUser(body) {
    try {
      const response = await axios.post(allEndPoints.signUpUser, body, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      return response.data;
    } catch (error) {
      console.error("Error:", error.response?.data || error.message);
      throw error;
    }
  }

  async signUpAdmin(body) {
    try {
      const response = await axios.post(allEndPoints.signUpAdmin, body, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      return response.data;
    } catch (error) {
      console.error("Error:", error.response?.data || error.message);
      throw error;
    }
  }
}
