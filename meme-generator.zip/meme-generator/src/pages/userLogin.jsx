import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Login.css";
import Authentication from "../services/authentication";

export default function UserLogin() {
  const authService = new Authentication();
  const [formData, setFormData] = useState({
    Username: "",
    password: "",
  });

  function handleChange(event) {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  }

  async function handleSubmit(event) {
    event.preventDefault();
    try {
      const response = await authService.userLogin(formData);
      console.log("hello");
      console.log(`Login successful:`, response.data);
    } catch (error) {
      console.error(`Login failed:`, response || error.message);
    }
  }

  return (
    <div>
      <h1>User Login</h1>
      <form className="form" onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter Username"
          name="Username"
          value={formData.Username}
          onChange={handleChange}
        />
        <input
          type="password"
          placeholder="Enter Password"
          name="password"
          value={formData.password}
          onChange={handleChange}
        />
        <button type="submit">Login</button>
      </form>
    </div>
  );
}
