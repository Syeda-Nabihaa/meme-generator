import React from 'react';
import {useState} from 'react';
import './Login.css'
import Authentication from '../services/authentication';
export default function AdminSignUp(){
  const data = {
    firstName:'',
    lastName:'',
    profession:'',
    number:'',
    email:'',
    password:'',
    role:''
  }
  const [userData,setUserData]=
    useState(data);

  function handleChange(event){
    setUserData({
      ...userData,
      [event.target.name]:event.target.value
    })
  }
 async function handleSubmit(event) {
    event.preventDefault();
    try{
      const response = await Authentication.signUpAdmin(userData);
      console.log("login successful :", response);
    }catch{
      console.log(`login failed:`,response);
    }

  }

  return(
    <div>
      <h1>Admin SignUp</h1>
      <form className="form"
        onSubmit ={handleSubmit}
        >
        <input 
          type="text"
          placeholder="Enter FirstName"
          name='firstName'
          value={userData.firstName}
          onChange = {handleChange}
          />
        <input 
          type="text"
          placeholder="Enter lastName"
          name='lastName'
          value ={userData.lastName}
          onChange = {handleChange}
          />
        <input 

          type="text"
          placeholder="Enter Your profession"
          name='profession'
          value= {userData.profession}
          onChange = {handleChange}
          />

        <input 
          type="number"
          placeholder="Enter number"
          name='number'
          value={userData.number}
          onChange = {handleChange}
          />
        <input 
          type="text"
          placeholder="Enter Email"
          name='email'
          value={userData.email}
          onChange = {handleChange}
          />

        <input 
          type="password"
          placeholder="Enter Password"
          name='password'
          value={userData.password}
          onChange = {handleChange}
          />
        <input 
          type="text"
          placeholder="Enter role"
          name='role'
          value={userData.role}
          onChange = {handleChange}
          />
        <input 
          type="text"
          placeholder="image"
          />
        <button>SignUp</button>
      </form>
    </div>
  )
}
