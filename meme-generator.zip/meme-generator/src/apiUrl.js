import {environment} from './environment/environment';

export const allEndPoints = {
  loginUser : `${environment.baseUrl}loginUser`,
  loginAdmin : `${environment.baseUrl}admin`,

  signUpAdmim : `${environment.baseUrl}addAdmin`,

  signUpUser : `${environment.baseUrl}addUser`
}

  
  
  
  


export default allEndPoints;