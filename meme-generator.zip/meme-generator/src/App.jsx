import './App.css';
import AuthRouting from './routes/routes';
import { Routes, Route } from 'react-router-dom';

export default function App() {
  return (
      <Routes>
        {AuthRouting.children.map((route, index) => (
          <Route 
            key={index} 
            path={`${AuthRouting.path}/${route.path}`} 
            element={route.element} 
          />
        ))}
      </Routes>
  );
}
