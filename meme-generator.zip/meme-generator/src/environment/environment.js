export const environment = {
  baseUrl:"http://quizbackend.codeaugment.com/api/"
}