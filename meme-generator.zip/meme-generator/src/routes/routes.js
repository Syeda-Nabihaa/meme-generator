import React from "react";

import AdminLogin from "../pages/adminLogin";
import AdminSignUp from "../pages/adminSignUp";
import UserSignUp from "../pages/UserSignup";
import UserLogin from "../pages/userLogin";

const AuthRouting = {
  path: "/",
  children: [
    {
      path: "/",
      element: <UserLogin />,
    },
    {
      path: "userSignUp",
      element: <UserSignUp/>,
    },
    {
      path: "AdminLogin",
      element: <AdminLogin />,
    },
    {
      path: "adminSignUp",
      element: <AdminSignUp />,
    },
  ],
};

export default AuthRouting;